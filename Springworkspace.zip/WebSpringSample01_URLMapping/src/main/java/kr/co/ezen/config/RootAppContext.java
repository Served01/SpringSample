package kr.co.ezen.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootAppContext {

}
