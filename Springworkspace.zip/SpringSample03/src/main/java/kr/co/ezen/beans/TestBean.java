package kr.co.ezen.beans;

public class TestBean {

	public TestBean() {
		System.out.println("생성자 입입니다~");
	}
	
	public void Adder() {
		System.out.println("송민수에게 1조원을 입금하였습니다.");
	}
	
}
