package kr.co.ezen.beans;

public class TestBean2 {
	
	public int Adder(int x, int y) {
		return x + y;
	}
	
}
