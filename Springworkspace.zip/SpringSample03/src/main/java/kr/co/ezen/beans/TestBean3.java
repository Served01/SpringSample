package kr.co.ezen.beans;

public class TestBean3 {
	
	public int Subtract(int x, int y) {
		return x - y;
	}
	
}
