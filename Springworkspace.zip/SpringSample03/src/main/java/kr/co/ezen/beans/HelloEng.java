package kr.co.ezen.beans;

public class HelloEng extends HelloWorld {

	@Override
	public void sayHalo() {
		
		System.out.println("Hi~~~");
		
	}


}
