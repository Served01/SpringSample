package kr.co.ezen.beans;

public class DataBean2 {
	
	private int data3;
	private int[] data4;
	
	public int getData3() {
		return data3;
	}
	public void setData3(int data3) {
		this.data3 = data3;
	}
	public int[] getData4() {
		return data4;
	}
	public void setData4(int[] data4) {
		this.data4 = data4;
	}
	
}
