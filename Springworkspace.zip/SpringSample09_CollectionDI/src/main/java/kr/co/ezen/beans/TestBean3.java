package kr.co.ezen.beans;

import java.util.Map;

public class TestBean3 {
	
	//중복 
	private Map<String, Object> map1;
	private Map<Integer, Object> map2;
	private Map<Double, Object> map3;
	
	public Map<String, Object> getMap1() {
		return map1;
	}
	public void setMap1(Map<String, Object> map1) {
		this.map1 = map1;
	}
	public Map<Integer, Object> getMap2() {
		return map2;
	}
	public void setMap2(Map<Integer, Object> map2) {
		this.map2 = map2;
	}
	public Map<Double, Object> getMap3() {
		return map3;
	}
	public void setMap3(Map<Double, Object> map3) {
		this.map3 = map3;
	}
	
	
	
	
	
	

	
	
}
