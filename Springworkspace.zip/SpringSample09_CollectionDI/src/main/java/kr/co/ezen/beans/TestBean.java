package kr.co.ezen.beans;

import java.util.List;

public class TestBean {
	
	private List<String> list1;
	private List<Integer> list2;
	private List<Double> list3;
	
	public List<String> getList1() {
		return list1;
	}

	public void setList1(List<String> list1) {
		this.list1 = list1;
	}

	public List<Integer> getList2() {
		return list2;
	}

	public void setList2(List<Integer> list2) {
		this.list2 = list2;
	}

	public List<Double> getList3() {
		return list3;
	}

	public void setList3(List<Double> list3) {
		this.list3 = list3;
	}

	
	
}
