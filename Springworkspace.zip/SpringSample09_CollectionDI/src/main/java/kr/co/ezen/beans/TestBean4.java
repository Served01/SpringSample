package kr.co.ezen.beans;

import java.util.Properties;

public class TestBean4 {
	
	private Properties properties;

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	
	
	
	
	
	

	
	
}
