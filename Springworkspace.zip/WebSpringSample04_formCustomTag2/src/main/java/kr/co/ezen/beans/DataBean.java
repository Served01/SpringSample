package kr.co.ezen.beans;

public class DataBean {
	
	private String userid_input;
	private String userid_output;
	
	
	public String getUserid_input() {
		return userid_input;
	}
	public void setUserid_input(String userid_input) {
		this.userid_input = userid_input;
	}
	public String getUserid_output() {
		return userid_output;
	}
	public void setUserid_output(String userid_output) {
		this.userid_output = userid_output;
	}
	
	
	
}
