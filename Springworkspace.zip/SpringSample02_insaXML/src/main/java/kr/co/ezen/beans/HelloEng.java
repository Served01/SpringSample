package kr.co.ezen.beans;

public class HelloEng extends HelloWorld2 {

	@Override
	public void sayHalo() {
		
		System.out.println("Hi~~~");
		
	}


}
