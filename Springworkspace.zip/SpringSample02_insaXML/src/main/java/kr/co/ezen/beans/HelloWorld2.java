package kr.co.ezen.beans;

public abstract class HelloWorld2 {
	
	public abstract void sayHalo();//추상 메소드 선언
	
}
