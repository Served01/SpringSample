package kr.co.ezen.beans;


public class DataBean3 {
	
	private String data7;
	private String data8;
	private int data9;
	
	public String getData7() {
		return data7;
	}
	public void setData7(String data7) {
		this.data7 = data7;
	}
	public String getData8() {
		return data8;
	}
	public void setData8(String data8) {
		this.data8 = data8;
	}
	public int getData9() {
		return data9;
	}
	public void setData9(int data9) {
		this.data9 = data9;
	}
	
	
	
	
}
