package kr.co.ezen.beans;

public class TestBean {
	
	private DataBean data1;
	private DataBean data2;
	private int data3;
	private double data4;
	private String data5;
	
	public DataBean getData1() {
		return data1;
	}
	public void setData1(DataBean data1) {
		this.data1 = data1;
	}
	public DataBean getData2() {
		return data2;
	}
	public void setData2(DataBean data2) {
		this.data2 = data2;
	}
	public int getData3() {
		return data3;
	}
	public void setData3(int data3) {
		this.data3 = data3;
	}
	public double getData4() {
		return data4;
	}
	public void setData4(double data4) {
		this.data4 = data4;
	}
	public String getData5() {
		return data5;
	}
	public void setData5(String data5) {
		this.data5 = data5;
	}
	
	
	
}
