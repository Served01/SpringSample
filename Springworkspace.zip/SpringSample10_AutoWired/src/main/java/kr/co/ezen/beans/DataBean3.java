package kr.co.ezen.beans;

public class DataBean3 {
	
	
	
}
