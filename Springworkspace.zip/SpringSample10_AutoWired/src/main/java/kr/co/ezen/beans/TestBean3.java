package kr.co.ezen.beans;

public class TestBean3 {
	
	//className으로 지정
	private int data1;
	private String data2;
	private double data3;
	private DataBean3 data4;
	private DataBean3 data5;
	
	
	
	public int getData1() {
		return data1;
	}
	public void setData1(int data1) {
		this.data1 = data1;
	}
	public String getData2() {
		return data2;
	}
	public void setData2(String data2) {
		this.data2 = data2;
	}
	public double getData3() {
		return data3;
	}
	public void setData3(double data3) {
		this.data3 = data3;
	}
	public DataBean3 getData4() {
		return data4;
	}
	public void setData4(DataBean3 data4) {
		this.data4 = data4;
	}
	public DataBean3 getData5() {
		return data5;
	}
	public void setData5(DataBean3 data5) {
		this.data5 = data5;
	}
	
	
	
	
	
}
