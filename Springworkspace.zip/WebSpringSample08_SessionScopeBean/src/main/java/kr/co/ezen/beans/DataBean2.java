package kr.co.ezen.beans;

public class DataBean2 {
	
	private String data4;
	private String data5;
	private int data6;
	
	public String getData4() {
		return data4;
	}
	public void setData4(String data4) {
		this.data4 = data4;
	}
	public String getData5() {
		return data5;
	}
	public void setData5(String data5) {
		this.data5 = data5;
	}
	public int getData6() {
		return data6;
	}
	public void setData6(int data6) {
		this.data6 = data6;
	}
	
	
	
}
