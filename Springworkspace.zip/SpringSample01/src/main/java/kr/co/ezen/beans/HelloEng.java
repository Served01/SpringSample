package kr.co.ezen.beans;

public class HelloEng {

	public static void Hello() {

		System.out.println("Hellow~");

	}

}
