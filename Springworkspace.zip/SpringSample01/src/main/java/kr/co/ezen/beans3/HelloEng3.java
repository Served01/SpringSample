package kr.co.ezen.beans3;

public class HelloEng3 extends HelloWorld2 {

	@Override
	public void sayHalo() {
		
		System.out.println("Hi~~~");
		
	}


}
