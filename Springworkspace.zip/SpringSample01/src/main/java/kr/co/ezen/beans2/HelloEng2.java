package kr.co.ezen.beans2;

public class HelloEng2 implements HelloWorld {

	public void sayHello() {

		System.out.println("Hellow2~");

	}

}
