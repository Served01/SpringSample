package kr.co.ezen.beans2;

public interface HelloWorld {
	
	public abstract void sayHello();//추상 메소드 선언
	
}
