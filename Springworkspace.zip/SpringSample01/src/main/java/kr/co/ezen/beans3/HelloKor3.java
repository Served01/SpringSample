package kr.co.ezen.beans3;

public class HelloKor3 extends HelloWorld2 {

	@Override
	public void sayHalo() {
		System.out.println("방가방가~~~");
		
	}


	
}
