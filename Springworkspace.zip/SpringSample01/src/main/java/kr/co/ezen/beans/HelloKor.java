package kr.co.ezen.beans;

public class HelloKor {

	public static void Hello() {

		System.out.println("안녕하세요~");

	}
	
}
